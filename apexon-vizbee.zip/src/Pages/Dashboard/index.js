import React from 'react'

function Dashboard() {
    return (
        <div>This is dashboard page</div>
    )
}

export default Dashboard