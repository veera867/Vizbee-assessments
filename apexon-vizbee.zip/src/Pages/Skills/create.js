import React from 'react'

function SkillCreate() {
  return (
    <div>SkillCreate</div>
  )
}

export default SkillCreate