import React from 'react'

function SkillEdit() {
  return (
    <div>SkillEdit</div>
  )
}

export default SkillEdit