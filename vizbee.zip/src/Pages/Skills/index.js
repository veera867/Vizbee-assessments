import React from 'react'

function Skills() {
    return (
        <div>This is skills page</div>
    )
}

export default Skills